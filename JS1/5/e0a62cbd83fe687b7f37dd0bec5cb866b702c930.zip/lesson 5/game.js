var current = works[0];
setans();

function setans() {
    document.getElementById('text').innerHTML = current.text;
    document.getElementById('answers').innerHTML = '';
    for (var key in current.answer){
        document.getElementById('answers').innerHTML += "<div onclick='current = works["+current.jump[key]+"]; setans();'>"+current.answer[key]+"</div>";
    }
}